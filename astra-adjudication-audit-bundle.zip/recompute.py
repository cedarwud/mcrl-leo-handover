"""Read-only package arithmetic/receipt audit; Python standard library only.

Usage:
    python recompute.py /path/to/unzipped/package --output audit.json

This script never imports the simulator, trains a learner, or accesses TEST.
Hashes establish byte consistency, not historic runtime or checkpoint authenticity.
"""
from pathlib import Path
import json,hashlib,math,collections,argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("package", type=Path, help="Extracted review-package root")
parser.add_argument("--output", type=Path, default=Path("independent-recomputation.json"))
args=parser.parse_args()
R=args.package
if not (R/"MANIFEST.sha256").is_file():
    parser.error("package must contain MANIFEST.sha256")
if args.output.resolve().is_relative_to(R.resolve()):
    parser.error("write the audit output outside the reviewed package")
def load(n):return json.loads((R/'evidence'/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(d):return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')).hexdigest()
a={}
a['manifest']={'entries':0,'mismatches':[]}
for line in (R/'MANIFEST.sha256').read_text().splitlines():
 h,n=line.split(maxsplit=1); n=n.lstrip('*');a['manifest']['entries']+=1
 if sha(R/n)!=h:a['manifest']['mismatches'].append(n)
for n in ['02-v020-repriced-c3-result.json','09-v021-fast-screen-result.json']:
 d=load(n);c=dict(d);s=c.pop('result_sha256');a[n]={'payload_hash_matches':canonical(c)==s,'file_sha256':sha(R/'evidence'/n)}
v20=load('02-v020-repriced-c3-result.json');v20i=load('03-v020-independent-verification.json');v21=load('09-v021-fast-screen-result.json');v21i=load('09b-v021-fast-screen-independent-verification.json');fit=load('04-repriced-q1-q2-source-fit.json')
a['cross_receipts']={
 'v020_contract_matches':sha(R/'contracts/02-v020-repriced-c3-contract.md')==v20['contract_sha256'],
 'v021_contract_matches':sha(R/'contracts/03-v021-expected-zr-fast-contract.md')==v21['contract_sha256'],
 'v020_fit_file_matches':sha(R/'evidence/04-repriced-q1-q2-source-fit.json')==v20['fit_merged_file_sha256'],
 'v020_verifier_runner_matches':sha(R/'source/run_v020_repriced_c3_gate.py')==v20i['runner_file_sha256'],
 'v020_verifier_summary_matches':all(v20[k]==v20i[k] for k in ['contrasts','decision','pooled_by_arm']),
 'v021_runner_matches':sha(R/'source/run_v021_expected_zr_fast_screen.py')==v21['runner_sha256'],
 'v021_independent_result_file_matches':sha(R/'evidence/09-v021-fast-screen-result.json')==v21i['source_result_sha256'],
 'v021_independent_payload_matches':v21['result_sha256']==v21i['source_payload_sha256'],
 'v021_independent_summary_matches':all(v21[k]==v21i[k] for k in ['criteria','decision','metrics'])}
def root(kind,w,i):
 raw=json.dumps(['keyed-branch-independent-v1','MCRL_V021_EXPECTED_ZR_FAST_V1',kind,w,i],ensure_ascii=True,separators=(',',':')).encode()
 return hashlib.sha256(hashlib.sha256(raw).hexdigest().encode()).hexdigest()
a['keyed_roots']={kind:all(root(kind,v21['world'],i)==v21[kind+'_field_root_digests'][i] for i in range(8)) for kind in ['integration','evaluation']}
a['keyed_roots']['16_unique']=len(set(v21['integration_field_root_digests']+v21['evaluation_field_root_digests']))==16
a['v021']={}
for arm,rows in v21['per_draw'].items():
 b=sum(r['bits'] for r in rows); e=sum(r['energy_j'] for r in rows);s=sum(r['served_users'] for r in rows);n=sum(r['total_users'] for r in rows)
 m={'bits':b,'energy_j':e,'ratio_of_sums_ee_bits_per_j':b/e,'served_fraction':s/n,'served_users':s,'total_users':n,'per_draw_ee_bits_per_j':[r['bits']/r['energy_j'] for r in rows]}
 a['v021'][arm]={'metrics':m,'stored_metrics_exactly_equal':m==v21['metrics'][arm], 'draw_ee_exactly_equal':all((r['bits']/r['energy_j']).hex()==r['ee_bits_per_j'].hex() for r in rows),'fixed_action_receipts_match':all(r['action_sha256']==v21['action_receipts'][arm] for r in rows) if arm!='E' else None,'relative_ee_pct_vs_B':100*((b/e)/v21['metrics']['B']['ratio_of_sums_ee_bits_per_j']-1)}
pos=sum(r['ee_bits_per_j']>b['ee_bits_per_j'] for r,b in zip(v21['per_draw']['R'],v21['per_draw']['B']))
a['v021_diagnostics']={'positive_R_vs_B':pos,'r_exposure':v21['r_exposure_users'],'n_exposure':v21['n_exposure_users'],'p_exposure':v21['p_exposure_users'],'k4_k8_action_agreement':v21['k4_k8_action_agreement'],'all_energy_values_identical':len({r['energy_j'] for rows in v21['per_draw'].values() for r in rows})==1,'decision':v21['decision'],'criteria':v21['criteria'],'R_vs_B_draw_relative_pct':[100*(r['ee_bits_per_j']/b['ee_bits_per_j']-1) for r,b in zip(v21['per_draw']['R'],v21['per_draw']['B'])]}
a['v020']={}
base=v20['pooled_by_arm']['BASE']
for arm,m in v20['pooled_by_arm'].items():
 ee=m['total_bits']/m['total_energy_j']
 a['v020'][arm]={'pooled_ee_recomputed':ee,'stored_ee_exactly_equal':ee==m['ratio_of_sums_ee_bits_per_j'],'bits_delta_pct':100*(m['total_bits']/base['total_bits']-1),'energy_delta_pct':100*(m['total_energy_j']/base['total_energy_j']-1),'ee_delta_pct':100*(ee/base['ratio_of_sums_ee_bits_per_j']-1)}
a['fit']={k:{'recomputed_mean_skill':sum(fit[k]['skills'])/len(fit[k]['skills']),'stored_mean_matches':sum(fit[k]['skills'])/len(fit[k]['skills'])==fit[k]['mean_skill'],'positive_count':sum(x>0 for x in fit[k]['skills'])} for k in ['q1_gate','q2_gate']}
a['stage1b']={}
allpooled={}
for n in ['06-c2-ha-stage1b-result.json','07-c2-ops3-stage1b-result.json']:
 d=load(n); by=collections.defaultdict(list)
 for row in d['rows']:by[row['policy_label']].append(row)
 out={'row_count':len(d['rows']),'row_aggregation_max_relative_error':0.,'pooled':{},'source_closure_note':d['source_closure_note'],'learned_q2_used':d['learned_q2_used']}
 for row in d['rows']:
  dt=row['total_energy_j']/sum(row['per_step_total_power_w'])
  for x,y in [(sum(row['per_step_bits']),row['total_bits']),(row['total_bits']/row['total_energy_j'],row['ratio_of_sums_ee_bits_per_j']), (sum(row['per_step_served_users']),row['served_user_steps']),(dt,47*.64)]:
   out['row_aggregation_max_relative_error']=max(out['row_aggregation_max_relative_error'],abs(x-y)/max(abs(y),1))
 for arm,rows in by.items():
  bits=sum(row['total_bits'] for row in rows); energy=sum(row['total_energy_j'] for row in rows);served=sum(row['served_user_steps'] for row in rows);total=sum(row['decision_count'] for row in rows)
  pooled={'rows':len(rows),'bits':bits,'energy_j':energy,'EE':bits/energy,'service':served/total}
  m=d['summaries']['pooled_by_arm'][arm]
  pooled['max_relative_error_vs_stored']=max(abs(pooled[k]-m[j])/max(abs(m[j]),1) for k,j in [('bits','total_bits'),('energy_j','total_energy_j'),('EE','ratio_of_sums_ee_bits_per_j'),('service','served_fraction')])
  out['pooled'][arm]=pooled;allpooled[arm]=pooled
 a['stage1b'][n]=out
a['stage1b_cross_deltas_pct']={f'{x}_vs_{y}':100*(allpooled[x]['EE']/allpooled[y]['EE']-1) for x,y in [('O12','P1'),('O123','P13'),('O123','O12'),('O123','O23'),('P123','P12'),('P12','P1')]}
a['binomial_rule']={'prob_6_or_more_of_8_at_null_0.5':sum(math.comb(8,k) for k in range(6,9))/2**8,'reject_prob_at_draw_success_0.7':1-sum(math.comb(8,k)*.7**k*.3**(8-k) for k in range(6,9))}
# Reapply the frozen decision from available numbers. Exposure and runtime
# mechanics remain receipt claims because the arrays/runtime are not packaged.
vm={arm:a['v021'][arm]['metrics'] for arm in a['v021']}
criteria={
 'mechanics_pass':all(v for k,v in v21['mechanics'].items() if k!='passed'),
 'r_exposure_positive':v21['r_exposure_users']>0,
 'r_gt_b':vm['R']['ratio_of_sums_ee_bits_per_j']>vm['B']['ratio_of_sums_ee_bits_per_j'],
 'r_gt_n':vm['R']['ratio_of_sums_ee_bits_per_j']>vm['N']['ratio_of_sums_ee_bits_per_j'],
 'r_gt_p':vm['R']['ratio_of_sums_ee_bits_per_j']>vm['P']['ratio_of_sums_ee_bits_per_j'],
 'service_guard':vm['R']['served_fraction']>=vm['B']['served_fraction']-.001,
 'positive_draws_at_least_6_of_8':pos>=6,
}
a['v021_recomputed_decision']={
 'criteria':criteria,
 'criteria_match':criteria==v21['criteria'],
 'decision':'GO_FULL_EXPECTED_ZR_GATE' if all(criteria.values()) else 'STOP_EXPECTED_ZR_FAST',
 'receipt_only_inputs':['runtime mechanics','action exposure count'],
}
a['v021_recomputed_decision']['decision_matches']=a['v021_recomputed_decision']['decision']==v21['decision']
v20_flags={}
for arm,c in v20['contrasts'].items():
    nline=sum(v>0 for v in c['by_lineage_relative_delta_ee'].values())
    nworld=sum(v>0 for v in c['by_world_relative_delta_ee'].values())
    service=c['treatment']['served_fraction']>=c['base']['served_fraction']-.001
    passed=(a['v020'][arm]['ee_delta_pct']>0 and nline==3 and nworld>=3 and service)
    v20_flags[arm]={'positive_lineages':nline,'positive_worlds':nworld,'service_noninferior':service,'passed':passed,'matches_stored':passed==c['passed']}
v20_decision=('GO_Q3_SOURCE_AND_LEARNER' if all(c['passed'] for c in v20_flags.values()) else 'REVISE_NOMINAL_Q3' if v20_flags['EXACT_ZR']['passed'] else 'REDESIGN_R3_TARGET')
a['v020_recomputed_decision']={'contrasts':v20_flags,'decision':v20_decision,'matches_stored':v20_decision==v20['decision'],'limit':'Subgroup margins and runtime mechanics are stored summaries; the 36 raw shards are absent.'}
# Additional numerical discrepancy diagnostic, not a changed acceptance rule.
a['fit']['q2_gate']['absolute_rounding_difference']=abs(a['fit']['q2_gate']['recomputed_mean_skill']-fit['q2_gate']['mean_skill'])
# Full current-user training-source ablations are not present in these payloads.
a['authentication_limits']=[
 'No checkpoint binaries, source-fit rows, V020 raw shards, or V021 score/action arrays are present.',
 'Chronology, global seed freshness, runtime mechanics, and historical reviewer independence cannot be authenticated from hashes alone.',
 'Stage1b row arithmetic does not close the failed source-closure check.',
]
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({k:v for k,v in a.items() if k not in ['v021','stage1b']},indent=2))
for n,d in a['stage1b'].items():print(n,'rows',d['row_count'],'max row rel err',d['row_aggregation_max_relative_error'],'max pooled rel err',max(v['max_relative_error_vs_stored'] for v in d['pooled'].values()))
