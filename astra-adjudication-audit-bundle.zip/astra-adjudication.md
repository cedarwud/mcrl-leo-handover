# Astra Pro package-only clean-room adjudication

## Pass-1 provisional record

**VERIFIED FACT — Read boundary.** This record was written before opening `START-HERE.md`, `CROSS-MODEL-STATE.md`, or `evidence/01-*`, `08-*`, `10-*`, and `11-*`. Pass 1 used the neutral entry, locator, source-copy limits, current contracts, permitted JSON, and source copies. No simulator, learner, or TEST was run.

**VERIFIED FACT — Causal graph.** Current geometry, candidate identities/mask, and committed link history plus joint actions determine link recurrence powers; power feasibility determines service. Service determines beam loads, active beams/satellites, and maximum-per-beam RF powers. Those powers and geometry/fading determine desired signals and co-channel interference; SINR and bandwidth sharing determine delivered bits. Beam RF powers determine amplifier supply, with per-beam circuitry and per-active-satellite overhead determining network energy. Actions also change next-step association, segment, radiation, and load history. Final EE is accumulated bits divided by accumulated energy. (`source/step.py:720–1034`.)

**DERIVATION — Remaining channel.** Holding Q1/Q2 fixed is not itself a physical intervention that removes their channels. Under ZR's stronger unilateral compatibility condition, however, non-focal associations and the radiating field remain fixed. Non-focal SINRs therefore remain fixed within a matched fading draw; the surviving non-focal effect is bandwidth redistribution. This support is not necessarily closed under simultaneous changes by several users. (`source/ee_axis_zero_marginal_c3.py:10–26`; `source/interference.py:349–398`.)

**DERIVATION — Actionable linearity.** Let B be the native row-wise argmax of Q1+Q2. Its reference ZR label is exactly zero. Every incompatible action has a nonpositive C3 score and cannot displace B under the same argmax/tie rule. On compatible actions, the negative-plus-positive ZR expression equals the ordinary signed sum of non-focal bit changes. Thus the nonlinear clipping issue demonstrated in the mechanics test is on an action-inert branch of this exact analytic selector; nonlinear channel-to-rate expectation still matters. (`source/ee_axis_expected_zr_c3.py:92–121`; `source/run_v021_expected_zr_fast_screen.py:108–113,280–290`; `source/test_w180_ee_axis_expected_zr_c3.py:17–35,74–96`.)

**VERIFIED FACT — Authentication ceiling.** All 55 manifest entries match. Both result payload hashes, both current contract hashes, the packaged runner references, the repriced-fit file reference, and the V0.21 independent-verification references match. All 16 integration/evaluation root digests can be rederived and are distinct. V0.21 per-draw arithmetic and 204 older Stage-1b trajectory summaries can be recomputed. V0.20 raw shards, checkpoints, fit source rows, and V0.21 score/action arrays are absent. Runtime mechanics and freeze chronology cannot be independently authenticated from hashes alone. Both older Stage-1b JSON files explicitly record a failed source-closure recheck. (`SOURCE-NOTES.md:3–5`; evidence JSON and the independent arithmetic audit.)

**VERIFIED FACT — Results.** V0.20's stored decision is `REVISE_NOMINAL_Q3`: exact pooled EE improves 0.985325%, nominal improves 0.424092%, but nominal fails one lineage. Exact total bits decrease 5.320531% while energy decreases 6.244329%; this is not evidence of an episode-level throughput-only benefit. V0.21's immutable experiment decision is `STOP_EXPECTED_ZR_FAST`: R changes eight users, loses to B, and wins only two of eight draws. All five arms have identical recorded energy and 94% service. R beats N and P. K4/K8 actions agree on 95 of 100 users. These are development observations, not learned marginal or efficacy evidence.

**INFERENCE — Discrepancies and unresolved premises.** A pathwise oracle's gain does not establish an observable-state estimator's gain. The full-scene Monte Carlo teacher and compressed relational learner inputs have not been shown to define the same conditional expectation; aggregate nominal interference omits explicit fading-source composition. A fixed cyclic P control tests score placement conditional on retained support, not removal of all action-specific information. The one-anchor rule can reject a potentially useful route and cannot locate the cause among finite-K error, anchor choice, surrogate calibration, or simultaneous-action interactions. Q1/Q2 source-fit skills and older Q2 oracle gains do not establish current learned-policy marginals. The Q2 stored mean skill differs from ordinary Python summation by approximately 2.2e-16, an immaterial rounding discrepancy.

**PROPOSAL — Provisional decision.** Preserve the experimental stop and close Expected-ZR rather than tune another variant. Redesign the R3 target only after a bounded information/ownership audit; keep C1/C2 unqualified for long training until matched learned-background evidence exists. No demonstrated contradiction currently requires abandoning three heads, and no demonstrated Q1/Q2 implementation failure yet justifies making their reopening the primary decision.

**PROPOSAL — Provisional reviewer token:** `REDESIGN_R3_NOW`.

## Executive verdict

**PROPOSAL — Redesign R3 now; do not promote Expected-ZR and do not begin 100/500-episode training.** Preserve the three-network, three-training-route requirement. The immediate next step is one bounded R3 target-and-information contract, followed only by its preregistered falsification. Keep the current C1/C2 price and implementations fixed as diagnostic backgrounds, but do not call those routes scientifically qualified.

**VERIFIED FACT — Immutable experiment token:** `STOP_EXPECTED_ZR_FAST`. Independently recomputed V0.21 arithmetic reproduces that decision. R loses to B by **0.400712%**, despite beating N and P; it wins only **2/8** evaluation draws. The package is post-result, not pre-result. (`evidence/09-v021-fast-screen-result.json`, `/per_draw`, `/criteria`, `/decision`; `evidence/09b-v021-fast-screen-independent-verification.json`.)

**INFERENCE — Meaning of the failure.** This rejects the specified K=8 estimator-plus-selector at the specified initial anchor under the frozen budget rule. It does **not** identify whether finite integration error, the conditional target, Q1/Q2 calibration, simultaneous actions, or anchor selection caused the loss. Closing the Expected-ZR research branch is justified as a binding development decision, not as a theorem that its population conditional expectation—or every spatial C3—must fail.

**INFERENCE — Token mapping.** There is no experimental GO; no demonstrated arithmetic or pairing defect warrants rerunning this screen; no material current Q1/Q2 implementation failure has been established; and no structural contradiction rules out three useful heads. The pass-1 recommendation therefore survives pass 2: **`REDESIGN_R3_NOW`**.

## Five most important new findings

### 1. The advertised nonlinear ZR distinction is action-inert in this exact selector

**DERIVATION.** Write the background score as \(s_u(a)=Q_1(u,a)+Q_2(u,a)\), with \(b_u=\arg\max_a s_u(a)\). Exact reference labels are zero. After support enforcement, an incompatible action has \(q_3(u,a)\le0\); consequently

\[
s_u(a)+q_3(u,a)\le s_u(b_u)=s_u(b_u)+q_3(u,b_u).
\]

Under the same deterministic tie rule, an incompatible action cannot displace B. On compatible actions, however,

\[
\sum_v\min(e_v,0)+\sum_v\max(e_v,0)=\sum_v e_v.
\]

Thus the decision-relevant ZR branch is **linear in the victim bit changes**. The mechanics test demonstrating “expectation of ZR differs from ZR of expected rates” makes its differing candidate incompatible: it tests a real numerical distinction on a branch that cannot change this analytic policy. Nonlinear fading-to-SINR-to-rate expectation still matters. This does not justify replacing the frozen formula after its result. (`source/ee_axis_expected_zr_c3.py:92–121`; `source/test_w180_ee_axis_expected_zr_c3.py:17–35,74–96`; `source/run_v021_expected_zr_fast_screen.py:280–290`.)

**INFERENCE.** This is a new qualification of the V0.21 motivation, not merely the already-known “EXACT is privileged” warning. It also explains why learning a large negative incompatible tail can consume model capacity without improving this selector. The proof does not automatically extend to an unclamped learned head.

### 2. The full-scene conditional teacher and the learner’s conditional target have not been equated

**VERIFIED FACT.** Integration calls the full physical evaluator. The relational encoder instead supplies seven action-context features and six victim-token features, including aggregate nominal desired signal and interference. It does not explicitly preserve each interfering satellite’s fading/shadowing composition. Fading is keyed by user/satellite context, and the physical draw includes elevation-dependent shadowing. (`source/run_v021_expected_zr_fast_screen.py:252–278`; `source/ee_axis_relational_zr_c3.py:56–96`; `source/step.py:1310–1371`; `source/keyed_fading.py:118–150`.)

**DERIVATION.** Equality of nominal interference sums does not generally imply equality of expected log-rate: one correlated interferer and several independently fading interferers can share a nominal sum but induce different interference distributions. Therefore

\[
\mathbb E[Z_3\mid X_{\rm full}]
\quad\text{and}\quad
\mathbb E[Z_3\mid\phi(X_{\rm full})]
\]

need not coincide for a compressed encoder \(\phi\).

**UNKNOWN.** No packaged collision census proves that this mismatch actually explains V0.21. Conversely, no sufficiency test proves that the current tokens preserve the required conditional expectation. R is a model-based observable-information candidate; it is not authenticated as a function of the eventual learner’s exact information set. This is not an allegation of realized-evaluation-fading leakage.

### 3. “95% agreement” is not convincing stability evidence for an eight-user intervention

**VERIFIED FACT.** K4/K8 agreement is 95/100 users, while R changes only 8/100 relative to B. K4 is the first four members of K8, not an independent integration replicate. Raw action vectors and score margins are absent. (`evidence/09-v021-fast-screen-result.json`, `/k4_k8_action_agreement`, `/r_exposure_users`; `source/run_v021_expected_zr_fast_screen.py:280–291`.)

**INFERENCE.** The five disagreements could be concentrated in consequential decisions; the package cannot resolve their overlap with the eight exposed users. Ninety-five percent global agreement therefore cannot rule out material integration instability. I disagree with the strength of the interpretation in `START-HERE.md:53`, while preserving the reported statistic. Exposure-conditioned agreement, action margins, and independently repeated integration—not another tuned ZR run—would be the appropriate diagnostics in a future, different target program.

### 4. P is a restricted score-placement perturbation, not an information-free control

**VERIFIED FACT.** P cyclically rotates values among compatible legal non-reference indices, in sorted slot order. It preserves the physical support mask, the reference, and the within-row score multiset. It is one deterministic permutation. (`source/run_v021_expected_zr_fast_screen.py:116–131`; `contracts/03-v021-expected-zr-fast-contract.md:21–29`.)

**DERIVATION.** Action-specific information remains in compatibility membership and in the background Q1/Q2 scores. Slot ordering can also retain physical structure under a one-position rotation. The untouched incompatible negative values are not, by themselves, an active confound here: finding 1 proves that they cannot beat B. The relevant retained information is support and its relationship to candidate identity and background margins.

**INFERENCE.** R>P supports only that this score placement was better than this particular corrupted placement on this anchor. It does not isolate all action-specific C3 information, prove conditional information beyond Q1/Q2, or rescue the failed R>B comparison.

### 5. A head-drop effect is not a Catfish-source effect—and changing the background can change Q3 itself

**VERIFIED FACT.** The historical mechanism specification explicitly distinguishes informed-source replacement from head deletion: the neutral and leave-one-route-out arms retain all three networks and equal gradient budgets. Current V0.20/V0.21 gates instead add analytic Q3 scores to a frozen Q1+Q2 background. The Q3 encoder is itself conditioned on the Q1+Q2 reference action. (`contracts/01-historical-v03-algorithm-spec.md:235–251`; `contracts/02-v020-repriced-c3-contract.md:56–60`; `source/run_v021_expected_zr_fast_screen.py:202–226`.)

**DERIVATION.** These are different interventions: zeroing a score; replacing an informed training source with an equal-budget neutral source and retraining; or removing a background head and rebuilding Q3’s reference-conditioned inputs. The last changes both the removed head and the downstream meaning of Q3. A frozen-input ablation and a re-encoded-policy ablation consequently answer different questions.

**PROPOSAL.** Recover this dormant distinction before the next learned gate. Preserve required FULL/DROP comparisons, but define their intervention precisely. For the claim “three Catfish training mechanisms help,” use informed-versus-neutral source replacements with three networks retained. Treat head-zeroing as a separate diagnostic. Do not rename the screen’s B=Q1+Q2 as the no-Catfish baseline.

## Evidence authentication and discrepancies

### What the upload authenticates

**VERIFIED FACT.** All **55** manifest-listed files match their SHA-256 values. Both current result payload hashes, both current contract hashes, the relevant packaged runner hashes, the V0.20 source-fit file reference, and V0.21 independent-verification references match. All **16** declared integration/evaluation root digests are independently derivable and distinct. These checks establish internal byte consistency, not independent provenance or historical freeze chronology. (`MANIFEST.sha256`; evidence `02`, `03`, `04`, `09`, `09b`; `source/keyed_fading.py:49–71`.)

**VERIFIED FACT.** I recomputed every V0.21 per-draw EE, pooled numerator/denominator, service fraction, draw-sign count, and numerical decision condition. Fixed-arm action hashes repeat consistently across evaluation draws. Exposure and runtime mechanics remain receipt inputs because their underlying arrays/runtime are not included.

| Evidence level | Authenticated observation | Limit |
|---|---|---|
| **VERIFIED FACT — Source prediction** | Packaged Q1 skills average **0.121739**; Q2 skills average approximately **0.860192**; each has three positive values. | Original training/validation rows and checkpoint binaries are absent. No physical marginal follows from these skills. |
| **VERIFIED FACT — Pathwise oracle policy** | V0.20 exact pooled EE is **116.038463 Mbit/J**, versus B **114.906263**, or **+0.985325%**. | Pooled arithmetic is reproducible; the 36 underlying shards and their runtime cannot be authenticated here. |
| **VERIFIED FACT — Observable/model-based estimator policy** | V0.20 nominal is **+0.424092%**, but fails its lineage rule. V0.21 expected R is **−0.400712%** and stops. | Neither is a successful current learned-Q3 policy. |
| **VERIFIED FACT — Older C2 oracle trajectories** | All **204** packaged episode rows reproduce their pooled summaries: 132 H-A rows and 72 OPS-3 rows. | Both files declare `learned_q2_used:false` and a failed source-closure recheck. These are different historical C2 objects. |
| **UNKNOWN — Learned mechanism and episode efficacy** | No current three-source learned FULL/neutral-replacement panel or held-out three-head efficacy result is present. | Oracle episodes and source fits cannot fill this gap. |

**VERIFIED FACT.** In V0.20, exact total bits fall **5.320531%** and energy falls **6.244329%**. The increase in their ratio is real in the stored totals, but it does not demonstrate an episode-level throughput increase. The stored subgroup summaries report exact positive in 3/3 lineages and 4/4 worlds; nominal is positive in 2/3 and 3/4 respectively. Nominal’s negative lineage is `2026092103`, and its negative world is `2026121501`. (`evidence/02-v020-repriced-c3-result.json`, `/pooled_by_arm`, `/contrasts`.)

**VERIFIED FACT.** The older Stage-1b contrasts also reproduce: H-A C2 **+11.699953%**, C3 **−0.484836%**, C1 **+0.644142%**; the Fable OPS-3 reading gives C2 **+9.479997%**, C3 **−2.687311%**, C1 **+5.891632%**. Both overall service guards fail. The two immutable historical strings are `C3_CONTEXT_FAIL`, not passes. (`evidence/05-c2-stage1b-report.md:159–229`; evidence `06` and `07`, `/rows`.)

**VERIFIED FACT — Small numerical discrepancy.** Ordinary Python summation gives the Q2 skill mean `0.8601919375184933`, versus stored `0.8601919375184931`: approximately **2.2×10⁻¹⁶**. This is immaterial rounding, not a gate discrepancy. Row-level Stage-1b arithmetic discrepancies are at floating-point roundoff scale; pooled summaries match.

**UNKNOWN — Claims that cannot be authenticated here.** The absent material includes checkpoint binaries; V0.20 raw shards; original source-fit rows/prediction arrays; V0.21 score and action arrays; complete imports, TLE authority, and runtime state; external freeze timestamps; global seed-freshness censuses; and the independent reviewers’ actual execution histories. `CROSS-MODEL-STATE.md` summarizes an Astra Ultra session, but its complete review and the raw 36-cell evidence are not supplied. A receipt saying those files were verified elsewhere is not present-day authentication of them. (`SOURCE-NOTES.md:3–5`; `CROSS-MODEL-STATE.md:19–28`.)

### Pass-2 comparison with prior accounts

**INFERENCE — Agreement without deference.** My independent account agrees with the prior reviews on privileged exact physics, unilateral/joint mismatch, the lack of learned efficacy, the current source-fit claim ceiling, and absence of a three-head impossibility theorem. It agrees with the controller’s rejection of CSE exact additivity. None of these agreements changes the pass-1 token.

**DERIVATION — Fable’s multiplier claim is too strong.** For positive aggregate energies,

\[
\eta_C-\eta_B=\frac{\Delta B-\eta_B\Delta E}{E_C}.
\]

A multiplier between the two realized EEs is sufficient for surplus-sign agreement, not necessary. Fable’s executive “necessary and sufficient” wording is incorrect. The later correction in `CROSS-MODEL-STATE.md:23` is sound. Survival of the exact positive sign after coherent repricing rejects an exclusively stale-price explanation; it does not establish ideal Q1/Q2 calibration.

**DERIVATION — CSE remains rejected.** Under the proposed CSE formula, C1+C3 becomes a unilateral total-bit change minus a focal cost-share change. The identity “shares sum to network power” holds within one configuration; it does not turn sums of differently evaluated unilateral changes into the actual simultaneous joint change. (`evidence/01-fable-c3-source-audit.md:210–240`; `evidence/08-root-fable-adjudication.md`.)

**VERIFIED FACT — Two historical premises are stale.** The older PDF’s unresolved h=0 persistence problem is now addressed: current OPS-3 initializes persistence with opening feasibility. The old “never change lambda” recommendation also predates the separately contracted coherent repricing. Neither should be imported as current authority. The Fable audit’s 7.5% Q2-agreement interpretation is expressly corrected in the root adjudication; it is not a valid current Q2-alone statistic. (`evidence/11-prior-chatgpt-review.pdf`, pp. 8–9; `source/ee_axis_ops3.py:709–728`; `evidence/08-root-fable-adjudication.md`.)

**VERIFIED FACT / DERIVATION — There is no single agreed projected-C3 formula.** The older PDF proposes \(e_0+H^{-1}\sum_{h=1}^H e_h\); the deep-research report proposes \((H+1)^{-1}\sum_{h=0}^H e_h\). These assign different relative weights to current and future effects and are not gauge-equivalent. A new contract must choose its estimand before outcomes, not blend these recommendations into a purported consensus. (`evidence/11-prior-chatgpt-review.pdf`, p. 10; `evidence/10-prior-chatgpt-deep-research.md`, “推薦 C3 的完整公式”.)

**INFERENCE — Additions beyond those reviews.** The actionable-branch linearity result, the exposure-denominator critique of 95% stability, and the specific P-control limitation were not identified in the supplied prior reviewer accounts. The full-scene/encoder issue sharpens their general partial-observability warning. The source-versus-head ablation distinction is recoverable from the historical specification, but was not carried through the current gate interpretation.

## Causal identifiability verdict for C3

### Action-to-EE graph

**VERIFIED FACT.** The source implements this graph:

```text
Geometry + physical candidate identities + committed link history
                         │
Joint legal actions ─────┤
                         ▼
Link recurrence powers → power-feasibility service gate
                         │
                         ▼
Served associations → beam loads / active beams / active satellites
                         │
                         ├→ max RF power per active beam
                         │       ├→ co-channel interference
                         │       └→ PA supply + beam circuitry + satellite overhead
                         │
Desired signal + fading + interference + noise → SINR
                         │
                         └→ bandwidth/load × log-rate → delivered bits

Actions also update association, segment, radiation, and load history.
Episode EE = accumulated delivered bits / accumulated network energy.
```

(`source/step.py:720–1034`; `source/interference.py:349–398`; `source/ee_axis_evaluation.py`.)

**VERIFIED FACT.** Decision-time candidate SINR uses a different, pre-action radiation context from executed SINR; it is not a readout of the selected joint outcome. Link-power recurrence is not a target-SINR controller. Legacy handover/load rewards are not additional terms in the final EE equation. (`source/step.py:1184–1296`; `source/step.py:763–815,936–1015`.)

**DERIVATION — What remains after C1/C2.** Fixing learned Q1/Q2 does not physically block any channel. Under the intended target ownership, C1 already prices current focal bits and all unilateral current network-energy change; OPS-3 covers projected focal continuation, marginal energy, and a persistence penalty. The unassigned views include current non-focal bandwidth/interference consequences and future non-focal consequences. Simultaneous beam shutdown is a real joint interaction, not automatically a new separable C3 energy term.

**DERIVATION — What ZR actually leaves.** Its compatibility condition is stronger than merely “same energy”: it also fixes service, active beams/satellites, and RF powers. With non-focal associations unchanged, non-focal SINRs are identical within a matched draw. The remaining unilateral effect is bandwidth redistribution. For a move from source beam r to destination d, this has the form

\[
\Delta B_{-u}=\Delta t\!\left[
\sum_{v\in r\setminus u}c_v\!\left(\frac1{n_r-1}-\frac1{n_r}\right)
+\sum_{v\in d}c_v\!\left(\frac1{n_d+1}-\frac1{n_d}\right)
\right],
\]

where \(c_v=W\log_2(1+\mathrm{SINR}_v)\). Empty sums contribute zero; a compatible departure that retains its source beam has \(n_r\ge2\). This is an explanatory derivation, not a proposed ZR retune. (`source/ee_axis_zero_marginal_c3.py:10–26`; `source/ee_axis_zero_marginal_c3_live.py:450–584`.)

**INFERENCE — Identifiability verdict.** A conditional non-focal physical view is defensible, but three separate propositions remain unproved: sufficiency of the deployed encoder, accuracy of the frozen-background approximation under joint moves, and survival of the resulting advantage after learning. Even perfect unilateral labels do not identify the realized simultaneous policy effect without assumptions or direct evaluation. Current C3 is not identified as a reliable third learned marginal.

### The three-head premise

**DERIVATION — Possibility is not the obstacle.** Consider three equally likely classes of states, constant energy, and one useful action correction in each class. Let head j uniquely supply the correction in class j; the other heads are neutral there. FULL makes all three corrections, each DROP makes two, and the baseline makes none. Then FULL > each DROP > BASELINE is possible. Nothing requires conflicting legacy metrics to improve.

**PROPOSAL — Conditions to test in this simulator.** The three views need distinct decision-relevant residual information; calibrated common-unit contributions; unique action corrections on reachable states; approximation errors smaller than the consequential action gaps; joint-interaction errors that do not reverse those corrections; and matched training-source ablations whose distribution shifts are measured. Shared input features are permissible—sharing geometry or load is not itself double-counting—but duplicated reward consequences are not.

**INFERENCE.** Current C1/C2/C3 do not establish those conditions. C1’s source skill is modest; C2 is an averaged, penalized projection rather than an exact remaining-return term; ZR restricts its useful support to unilateral redistribution; and no current equal-budget three-source learned panel is present. Common units and reference centering are insufficient. This is an unresolved empirical premise, not a demonstrated structural contradiction.

## V0.21 fast-screen verdict

### Conditional-expectation and fairness audit

**VERIFIED FACT — Full-label order is correct.** Each integration draw evaluates the complete nonlinear label, centers it, enforces positive support, divides by common kappa, and only then contributes to the mean. The mean is checked against the retained per-draw score surfaces. It does not first average fading or rates. (`source/ee_axis_expected_zr_c3.py:92–121,185–234`.)

**DERIVATION — Conditional target.** Under the declared keyed-field model, the arithmetic estimates the mean label at one fixed full scene and reference. It does not average over geometry, histories, other Q1/Q2 lineages, or future policy responses. The observation and reference remain fixed. The distinction between that full-scene conditional mean and the learner-encoder conditional mean remains as described in finding 2.

**VERIFIED FACT / INFERENCE — Field separation.** Integration and evaluation use separate namespaces; their declared root digests are disjoint and reproducible. Candidate/reference comparisons preserve matched physical draws, including same-satellite correlations. This is a coherent pseudo-independent sampling design. Digest inequality alone is not a statistical independence test or proof of globally fresh seeds. (`source/keyed_fading.py:49–71,118–150`; `source/run_v021_expected_zr_fast_screen.py:233–278`.)

**VERIFIED FACT — Compatibility and support.** The code checks mask, reference, interval, and compatibility invariance across integration draws and compares compatibility with the predecision reconstruction. Because service and power do not depend on these fading draws, such invariance has a physical basis. Post-centering support is enforced for the analytic expected surface. The old learned relational head does not perform that final clamp and has not inherited this guarantee. (`source/ee_axis_expected_zr_c3.py:45–89,215–222`; `source/ee_axis_relational_zr_c3_head_v019.py:193–209`.)

**VERIFIED FACT — Action timing.** B/N/R/P actions are constructed before evaluation fields are used. They are evaluated on common fields and the same anchor. E alone recomputes its action using the current evaluation draw. This is appropriate as a privileged diagnostic, not an attainable upper bound or a fair deployable competitor. There is no observed cross-arm action injection in the inspected runner. (`source/run_v021_expected_zr_fast_screen.py:280–342`.)

**INFERENCE — Overall fairness.** Pairing and frozen timing are sound for comparing these specified policies on this anchor. They do not make E deployable, P information-free, or the single anchor representative. The source and receipts support intended non-mutation, but the absent complete runtime prevents independent replay authentication.

### Recomputed result

| Arm | EE, Mbit/J | Change versus B | Interpretation |
|---|---:|---:|---|
| **VERIFIED FACT — B** | 129.793009 | — | Frozen Q1+Q2 |
| **VERIFIED FACT — E** | 129.911956 | +0.091643% | Privileged pathwise diagnostic |
| **VERIFIED FACT — N** | 128.837148 | −0.736451% | Nominal analytic surface |
| **VERIFIED FACT — R** | 129.272913 | −0.400712% | Fixed K=8 expected surface |
| **VERIFIED FACT — P** | 128.554178 | −0.954467% | Restricted permutation control |

**VERIFIED FACT.** All forty arm/draw energy values are identical; each arm pools **112,754.619205 J** and **752/800** served opportunities. Thus the observed ranking is entirely a bit-delivery ranking. R’s reported exposure is eight users. R>N, R>P, exposure, and service pass; R>B and six-positive-draws fail. (`evidence/09-v021-fast-screen-result.json`, `/per_draw`, `/metrics`, `/criteria`.)

### Is K=8/L=8 suitable for rejection-oriented triage?

**INFERENCE — Yes, with a narrow purpose.** It is suitable as a precommitted, inexpensive rule for declining further investment. It is not suitable for distinguishing estimator failure from target-family failure, demonstrating population inefficacy, or establishing generalization. Preregistration prevents convenient reinterpretation; it does not manufacture statistical power.

**DERIVATION — Sign-rule calibration.** Under independent continuous win signs with null win probability 1/2,

\[
P(\text{at least 6 wins of 8})=\frac{28+8+1}{256}=14.453125\%.
\]

That clause alone is not a 5% significance test. With per-draw win probability 0.7, it still fails about **44.82%** of the time. These are illustrative binomial calculations, not the full compound rule’s false-pass rate and not estimates of this route’s true win probability.

**INFERENCE — False-reject modes.** An initial anchor may omit the segment histories and joint shutdown opportunities that mattered in V0.20. Eight integration draws may misrank a few pivotal actions. The win-count rule can reject a positive mean effect driven by infrequent larger gains. Strict superiority to N and P can reject a useful tie. None identifies a universally bad target.

**INFERENCE — False-pass modes.** A favorable anchor and eight lucky evaluation draws can pass without cross-world robustness. R>P can merely reflect a harmful permutation. A gain can compensate for Q1/Q2 calibration rather than contribute an independently useful source mechanism. A successful analytic policy can still fail when compressed into a learned head or when histories change.

**PROPOSAL — Disposition.** Keep `STOP_EXPECTED_ZR_FAST`. Do not raise K/L, change anchors, adjust support, reverse signs, or try another nominal/ZR learner against this outcome. Also do not state that equal-energy step-0 failure refutes the multi-step denominator-saving phenomenon observed in V0.20. The two tests have different estimands.

## C1/C2 reopen-or-hold verdict

**PROPOSAL — Hold formulas and price; reopen qualification, not speculative retuning.** Neither head is “solved.” Their missing evidence must be supplied before long training, but the package does not demonstrate a material current Q1/Q2 implementation failure that should replace R3 redesign as the primary recommendation.

**VERIFIED FACT / DERIVATION — C1.** C1’s target owns current focal bits minus lambda times all unilateral network-energy change. Its current price is **118,424,222.8550065 bit/J**, and its refit rung is 10. A correct price unit does not guarantee action calibration or capture simultaneous shared-energy savings. The stored mean skill of 0.121739 is source-prediction evidence, not a C1 Catfish-source advantage. (`source/ee_surplus_targets.py:191–207,239–266`; `contracts/02-v020-repriced-c3-contract.md:9–35`; `evidence/04-repriced-q1-q2-source-fit.json`.)

**PROPOSAL — C1 minimum evidence.** Authenticate its actual checkpoint and relabeled source rows; verify current-state versus label timing and common units; demonstrate decision-relevant skill against neutral-source and simple null controls; and test whether informed C1 improves the learned joint policy over an equal-budget neutral C1 replacement. Retain total bits and energy separately so calibration repair is not mislabeled as a new causal channel.

**VERIFIED FACT / DERIVATION — C2.** Current OPS-3 conditions persistence on opening service, makes subsequent failure absorbing, uses native projected geometry, and averages future terms

\[
Z_2(a)=\frac1{H_t}\sum_{h=1}^{H_t}
\left[\chi_h\Delta t\big(R_{u,h}-\lambda\Delta P_h\big)
-(1-\chi_h)\kappa\right].
\]

The mean and fixed outage penalty are substantive surrogate choices, not an exact future ratio-of-sums decomposition. The projected background keeps committed non-focal loads and RF powers frozen while advancing geometry. (`source/ee_axis_ops3.py:19–29,709–782`; `source/ee_axis_ops3_live.py:666–740`.)

**VERIFIED FACT — A suspected price bug is not established.** Although the formula module retains an old default lambda, the V0.21 Q2 inference path copies only forecast features and masks into the learned Q2—not its computed target values. Those features do not include lambda. The default alone is therefore not proof that the repriced Q2 was silently evaluated at the old price. Actual checkpoint authenticity remains unknown. (`source/ee_axis_v014_q2_state.py:29–46,141–183`; `source/run_v021_expected_zr_fast_screen.py:193–200`.)

**PROPOSAL — C2 minimum evidence.** Authenticate the repriced checkpoint/source linkage; verify opening feasibility against execution, absorbing persistence, terminal zero, legal masks, frozen-background semantics, and target-free inference features. Then measure current learned Q2’s physical marginal and informed-source benefit on the same backgrounds intended for C3. Do not substitute the older +9.48% approximate-oracle result, a joint Q2+Q3 agreement statistic, or the 0.860192 source skill.

**INFERENCE.** The minimum requirement is not that every auxiliary diagnostic be positive. It is that the declared intervention, source comparison, and deployed policy are the same objects. A demonstrated mismatch there would justify `REOPEN_C1_C2_BEFORE_C3`; its mere possibility does not.

## Minimum path to 100/500ep training

**PROPOSAL — One finite program, with no rescue ladder.** The following is authorization logic, not a claim that these experiments were run.

| Stage | Bounded work | Stop rule |
|---|---|---|
| **PROPOSAL — 0. Contract and provenance** | One target/state/ablation contract; restore full executable closure and checkpoint/source receipts; freeze price, kappa, masks, timing, baseline definitions, source quotas, and reference rebuilding. | No physical screen while a deployability, source-identity, or target-ownership defect is unresolved. |
| **PROPOSAL — 1. Target falsification** | At most the two families below. Freeze both before new outcomes. Use one common panel of **12 outcome-blind anchors across four fresh development worlds**, covering initial, interior, and late history. Cap stochastic integration and evaluation at **32 draws each per retained anchor**; fix the actual count before opening outcomes. Include single and simultaneous moves. | Reject a family for causal-null violations, information insufficiency, no decision exposure, or systematic reversal of its proposed benefit under joint execution. No sign/scale/support/horizon/seed revision. Select at most one survivor by a predeclared rank; neither survives means stop this development round. |
| **PROPOSAL — 2. Source-to-learner transfer** | One fixed learner configuration and checkpoint rule per route, three initializations, disjoint source-validation worlds, matched informed/neutral sample and update budgets. Authenticate C1/C2 as well as the selected R3. | Stop for nonfinite/illegal scores, gauge/support violations where applicable, label leakage, failed decision-relevant null comparisons, or absence of informed-source benefit. No rung or architecture search after reveal. |
| **PROPOSAL — 3. Learned policy gate** | Four new paired worlds × three lineages × six policies: FULL, three neutral-source replacements, all-neutral, and external M0—at most **72 short evaluation rollouts**. Head-zero diagnostics may add at most **36**, with frozen-input versus rebuilt-reference semantics declared. These are evaluation rollouts, not training episodes. | Require the stipulated FULL > each DROP > named BASELINE ordering, all binding service guards, exposed route effects, and preregistered lineage/world stability. Report both all-neutral and M0; do not quietly interchange them. Failure ends the candidate. These small-panel signs remain developmental. |
| **PROPOSAL — 4. 100, then 500 training episodes** | Only after stages 0–3 pass, run the fixed matched training arms to the planned 100-episode checkpoint. Promote once to 500 only under its separately frozen validation rule. | No repeated validation peeking, seed replacement, best-rung selection, or change of targets after failure. A failed 100-episode gate does not trigger 500 as a rescue. A failed 500-episode gate ends the program. |

**PROPOSAL — Fairness details.** Preserve three networks in all source-ablation arms. Replace an informed source with its equal-budget neutral counterpart rather than removing gradient opportunities. Match training/evaluation worlds and count worlds—not crossed lineages—as physical replication. Freeze which baseline is binding; keep the original MODQN M0 distinct from all-neutral training and from B=Q1+Q2. Retain any stricter existing service condition rather than silently replacing it with a tolerance.

**PROPOSAL — Efficacy boundary.** The 100/500 checkpoints are development decisions. Final efficacy requires a separately powered, preregistered, frozen-policy evaluation with no checkpoint selection on that evaluation set. The package supplies no variance or cost basis for an honest confirmatory sample-size claim now. TEST remains unopened in this review and is not part of the proposed exploratory screens.

## Post-V0.21 ranked R3 alternatives

**PROPOSAL — Only two families.** Neither is a modified ZR support gate, a cost-share correction, or a sign/scale search. Shared physical inputs are allowed; the exclusions below concern duplicated target consequences. Both are hypotheses, not efficacy claims.

### Rank 1 — Controlled radiation-to-victim rate externality

**PROPOSAL — Target.** Isolate the current non-focal rate change caused by a focal action’s change to the radiating field: activation/deactivation and max-RF-power leadership. Hold each victim’s bandwidth allocation at the reference allocation, so occupancy redistribution is deliberately excluded:

\[
Z_3^{\rm rad}(u,a)=\Delta t\,\mathbb E\!\left[
\sum_{v\ne u}\frac{W_v}{n_v^b}
\left\{\log_2\!\left(1+\frac{S_v}{N_v+I_v(a)}\right)
-\log_2\!\left(1+\frac{S_v}{N_v+I_v(b)}\right)\right\}
\,\middle|\,\mathcal I_t\right].
\]

Use the same non-focal serving links, matched draw, and canonical radiation law in both branches; divide by the common kappa. Retain signed differences. This is a controlled mediator effect, not a claim that the complete executed action changes only interference.

**PROPOSAL — Exclusions.** No focal bits; no current or future energy term; no C2 persistence/outage reward; no bandwidth-load redistribution; no ZR compatibility gate. C1 continues to price the energy cost of changing radiation. This examines a physical channel that the useful ZR support specifically suppresses.

**PROPOSAL — Identifying deployment state.** Candidate physical identities and opening powers; committed non-focal associations and RF maxima; beam-to-victim geometry and cochannel incidence; victim serving signals/noise; and enough per-satellite/elevation structure to represent fading correlations. Aggregate nominal interference alone is not certified sufficient. If these are not available as declared predecision telemetry, reject this state/target pair rather than import hidden simulator state.

**PROPOSAL — Fast falsifier.** Use a sealed equal-load cochannel panel that crosses a candidate’s max-power-leadership boundary, plus a matched radiation-clamped negative control. The target must vanish in the clamped control. If its deployable surface cannot discriminate the signed victim-rate effect in the unclamped cases or produces no useful action exposure, stop before learning. Subsequent joint-policy failure still rejects the candidate even if this causal test passes.

**INFERENCE — Why first.** It is narrower and easier to attribute than a full future externality; it excludes the bandwidth-only mechanism already screened; and it directly tests whether a genuinely different leftover channel is decision-relevant. Its likely weakness is insufficient magnitude or dominance by joint-action interactions, not absence of a physical causal path.

### Rank 2 — Future-only non-focal persistence externality

**PROPOSAL — Target.** Measure the future delivered-bit burden of the focal segment on other users over the same bounded offsets used by C2, **excluding h=0**:

\[
Z_3^{\rm future}(u,a)=\frac1{H_t}\sum_{h=1}^{H_t}
\mathbb E\!\left[\Delta B_{-u,h}(a;b)\mid\mathcal I_t\right],
\qquad Z_3^{\rm future}=0\text{ when }H_t=0.
\]

Build one common no-focal background at each offset and compare insertion of candidate and reference segments. Use successful opening and absorbing persistence, the native clock, and no future learned-policy query. Freeze the background’s load/power evolution convention explicitly. This is a projected physical surrogate, not the total future-policy effect.

**PROPOSAL — Exclusions.** No h=0 ZR term; no focal future bits; no energy contribution; no separate service-risk penalty; no legacy handover/load reward. C2’s persistence descriptors can be shared as physical inputs without paying its persistence reward twice.

**PROPOSAL — Identifying deployment state.** Native orbital/D2 projection, candidate and committed victim physical associations, segment histories, projected coupling and eligibility, peer load/RF state, and conditional channel descriptors. The peer-background model must be derivable from the live information set, not from actual future actions or outcomes.

**PROPOSAL — Fast falsifier.** On a frozen interior/late-anchor panel with identifiable differences in projected victim persistence, compare its preferred simultaneous action with B over the declared short continuation. If the predicted non-focal benefit systematically reverses under those joint continuations—or vanishes despite nontrivial victim exposure—reject this family without changing its horizon or importing realized future-policy information.

**INFERENCE — Why second.** It addresses information absent from the equal-energy initial-anchor test, and C2 does not already own future non-focal bits. Its costs are stronger frozen-background assumptions and greater interaction error. It must not be described as merely completing an exact C1+C2+C3 return identity.

**PROPOSAL — Terminal boundary.** If neither frozen family survives the bounded program, report that no supported three-Catfish candidate was found under the fixed architecture and budget. End the development round. That is not a mathematical proof warranting `STOP_THREE_HEAD_REQUIREMENT_STRUCTURALLY`, and it does not authorize another ZR variant.

## What the paper may and may not claim now

**VERIFIED FACT — May report, with scope.** The packaged source defines real focal, temporal, and non-focal physical pathways. Coherent repricing was followed by a positive stored exact-ZR development comparison and a nominal stability failure. Expected-ZR subsequently failed its frozen one-anchor rule, with the numbers and immutable token reported above. Older C2 oracle direction screens were favorable for C2 but unfavorable for C3 and failed their complete service/method gates.

**DERIVATION — May state.** Three useful scalar-aligned views and simultaneous positive marginals are mathematically possible; neither follows automatically from the other. Zero-energy compatibility narrows the useful unilateral ZR channel to bandwidth redistribution. The historical share identity does not establish CSE joint additivity. The present surrogate sum is not an exact decomposition of final ratio-of-sums EE.

**UNKNOWN — May not claim.** No authenticated current result shows that all three learned Catfish source mechanisms improve deployment EE; that FULL > every required DROP > BASELINE holds for the final learned method; that Expected-ZR failure isolates estimator error or disproves all spatial C3s; that R is learnable from the exact deployed encoder; that E is an attainable upper bound; or that source closure, raw-shard reproduction, checkpoint authenticity, and freeze chronology have been established from this upload.

**PROPOSAL — Final recommendation.** Preserve the experimental stop. Freeze one bounded R3 ownership-and-identifiability redesign, retain C1/C2 only as unqualified diagnostic backgrounds, and require matched learned-source evidence before any 100/500-episode program.

REDESIGN_R3_NOW
