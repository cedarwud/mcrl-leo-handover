# Round 11 package — two questions, uploaded together

Upload this whole zip to **both** conversations. Each prompt says which question it is.

* `prompts/Round-11A-supermodularity.md` — deep research. Is the objective structurally
  incapable of positive interaction? If it is submodular, the C3 component is dead by
  proof and no further computation is needed.
* `prompts/Round-11B-fade-margin-practice.md` — question and answer with an engineering
  focus. Is our fade-margin rule a real design or a modelling artefact? It contains one
  question that directly asks whether our own stated reasoning is wrong.

## What is in here
* `sealed/` — the frozen physics declaration and the two amendments that set the margin
  rule and the causal decode rule. These are the contract; they are not up for revision
  by the answer, but the answer decides whether we amend them before the main run.
* `evidence/V025-CONTROLLER-FINDING-FIGURE1-AND-BACKOFF-2026-09-09.md` — the finding that
  prompted both questions. Read this second, after the prompt.
* `evidence/V025-ENGINE-STAGE4H-REPORT-2026-09-09.md` — the engine report confirming the
  decode-causality correction, with the paired before-and-after table.
* `evidence/figure1_compute.py` — the self-contained closed-form model of the mechanism
  figure. Every constant is in the file; nothing is imported from the simulator.
* `evidence/reserve_sensitivity.py` and its output — the local recomputation showing that
  a user at the lowest target mode is credited zero bits under any reserve.

## The single most important thing to check
Section 3 of `Round-11B` asks whether our reasoning against re-solving the margin into
transmit power is mistaken. We would rather be told we are wrong now than publish it.
